import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-f-aq',
  templateUrl: 'f-aq.html'
})
export class FAQPage {

  constructor(public navCtrl: NavController) {
  }
  
}
